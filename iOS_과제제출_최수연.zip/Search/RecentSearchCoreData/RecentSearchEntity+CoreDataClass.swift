//
//  RecentSearchEntity+CoreDataClass.swift
//  Search
//
//  Created by Suvely on 2021/12/28.
//
//

import Foundation
import CoreData

@objc(RecentSearchEntity)
public class RecentSearchEntity: NSManagedObject {
    static let name = "RecentSearchEntity"
}
